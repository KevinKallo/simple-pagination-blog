`npm run dev` build styles
`php artisan serve` run webserver
