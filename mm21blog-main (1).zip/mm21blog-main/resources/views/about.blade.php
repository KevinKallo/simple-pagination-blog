@extends('partials.layout')

@section('content')
    <h1 class="text-3xl font-bold underline">
        About
    </h1>
@endsection
